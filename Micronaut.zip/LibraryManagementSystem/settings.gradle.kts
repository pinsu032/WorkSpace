

rootProject.name="LibraryManagementSystem"

